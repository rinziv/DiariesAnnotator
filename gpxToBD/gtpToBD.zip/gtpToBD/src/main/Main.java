package main;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.vividsolutions.jts.io.ParseException;

import br.ufsc.core.Stop;
import br.ufsc.core.TPoint;
import br.ufsc.core.Trajectory;

import util.GPXManipulator;


public class Main {
	
	
	
	public static void main(String[] args) throws SQLException, ParseException{
		
		
		if(args.length!=2){
			System.out.print("Error! Wrong number of arguments");
			System.exit(0);
		}
		
		File fileConfig = new File(args[0]);
		BufferedReader in;
		try {
			in = new BufferedReader(new FileReader(fileConfig));
		
        
        Connection conn = null;
		String url = in.readLine();
	    String db = in.readLine();
	    String user = in.readLine();
	    String pass = in.readLine();

        if (user == "")
            conn = DriverManager.getConnection(url+db);
        else
            conn = DriverManager.getConnection(url+db,user,pass);
        
       
        
        ((org.postgresql.PGConnection) conn).addDataType("geometry",org.postgis.PGgeometry.class);

		Statement sn = conn.createStatement();
		
		String sqlCreateTables= "CREATE TABLE fulltrajgpx "+
								"( "+
								"  gid serial NOT NULL, "+
								"  tid integer, "+
								"  time timestamp without time zone, "+
								"  lat numeric, "+
								"  lon numeric,"+
								"  geom geometry, "+
								"  CONSTRAINT fullTrajGpx_pkey PRIMARY KEY (gid) "+
								")";
		
		try{
			sn.execute(sqlCreateTables);
		}catch (Exception e) {
			//e.printStackTrace();
		}
		
		sqlCreateTables= "CREATE TABLE movestrajgpx "+
								"( "+
								"  gid serial NOT NULL, "+
								"  tid integer, "+
								"  time_start timestamp without time zone, "+
								"  time_end timestamp without time zone, "+
								"  geom geometry, "+
								"  CONSTRAINT movesTrajGpx_pkey PRIMARY KEY (gid) "+
								")";
		
		try{
			sn.execute(sqlCreateTables);
		}catch (Exception e) {
			//e.printStackTrace();
		}
		
		sqlCreateTables= "CREATE TABLE stopstrajgpx "+
								"( "+
								"  gid serial NOT NULL, "+
								"  tid integer, "+
								"  time_start timestamp without time zone, "+
								"  time_end timestamp without time zone, "+
								"  geom geometry, "+
								"  CONSTRAINT stopsTrajGpx_pkey PRIMARY KEY (gid) "+
								")";
		
		try{
			sn.execute(sqlCreateTables);
		}catch (Exception e) {
			//e.printStackTrace();
		}
		
		
		String dir = args[1]; 
		File diretorio = new File(dir); 
		File fList[] = diretorio.listFiles(); 
		
		GPXManipulator gpxMan = new GPXManipulator(fList);
		gpxMan.setParameters(Integer.parseInt(in.readLine()), Double.parseDouble(in.readLine()), 
				Double.parseDouble(in.readLine()), Integer.parseInt(in.readLine()));
		
		Trajectory totalTrajectory = gpxMan.loadPointsAsTrajectory();	
		
   
	    ResultSet rs = sn.executeQuery("SELECT tid FROM fulltrajgpx ORDER BY tid desc LIMIT 1");
	    
	    int tid;
	    
	    if(rs.next()){
	    	tid = rs.getInt(1)+1;
	    }else{
	    	tid = 0;
	    }
		
		String insertSQL = "INSERT INTO fulltrajgpx (tid, time, lat, lon, geom) values";
	    
		for (int i =0; i<totalTrajectory.getLen(); i++){
			TPoint p = totalTrajectory.getPoint(i);
			insertSQL+= "("+tid+",cast('"+p.getTimestamp()+"' as timestamp),"+p.getY()+","+p.getX()+"," +
					"	ST_MakePoint("+p.getX()+","+p.getY()+")),";
		}
		
		insertSQL = insertSQL.substring(0, insertSQL.length()-1);
		//System.out.println(insertSQL);
		sn.execute(insertSQL);
		
		List<Trajectory> moves = gpxMan.splitUserTrajectory(totalTrajectory);
		
		insertSQL = "INSERT INTO movestrajgpx (tid, time_start, time_end, geom) values";
		
		for(int y = 0; y<moves.size(); y++){
			Trajectory move = moves.get(y);
			String geom = "";
			for (int i =0; i<move.getLen(); i++){
				TPoint p = move.getPoint(i);
				geom = geom+"ST_MakePoint("+p.getX()+","+p.getY()+"),";
			}
			geom = geom.substring(0, geom.length()-1);
			insertSQL+= "("+tid+",cast('"+move.getPoint(0).getTimestamp()+"' as timestamp),cast('"+move.getLastPoint().getTimestamp()+"' as timestamp)," +
			"	ST_SetSRID(ST_MAKELINE(ARRAY["+geom+"]),4326)),";
		}
		
		insertSQL = insertSQL.substring(0, insertSQL.length()-1);
		sn.execute(insertSQL);
		
		
		List<Stop> stops= gpxMan.getStops();
		
		insertSQL = "INSERT INTO stopstrajgpx (tid, time_start, time_end, geom) values";
		
		for(int y = 0; y<stops.size(); y++){
			Stop stop = stops.get(y);
			String geom = stop.getGeom();
			insertSQL+= "("+tid+",cast('"+stop.getStartTime()+"' as timestamp),cast('"+stop.getEndTime()+"' as timestamp)," +
			"	"+geom+"),";
		}
		
		insertSQL = insertSQL.substring(0, insertSQL.length()-1);
		System.out.println(insertSQL);
		sn.execute(insertSQL);
		
		} catch (IOException e1) {
			e1.printStackTrace();
		}

	}
 
}
